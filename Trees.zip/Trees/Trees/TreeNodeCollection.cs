﻿namespace Trees
{
    internal class TreeNodeCollection
    {
    }
}