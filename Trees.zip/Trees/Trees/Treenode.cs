﻿using System;
using static System.Console;
using System.IO;
using System.Linq;
using System.Globalization;
using System.Data;
using System.Collections.Generic;

namespace Trees
{
    class Treenode
    {
      public Treenode()
        {

        }
        public void CreatingSave(string fileName, Treeview tree)
        {
            using (StreamWriter streamWriter = new StreamWriter(fileName))
            {
                TreeNodeCollection nodes = Treeview.nodes;
                foreach (Treenode n in nodes)
                {
                    WriteRecursive(streamWriter, n);
                }
                streamWriter.Close();

            }

        }

        private void WriteRecursive(StreamWriter streamWriter, Treenode n)
        {
            throw new NotImplementedException();
        }
    }
    
    
   
}
