﻿using System;
using static System.Console;
using System.IO;
using System.Linq;
using System.Globalization;
using System.Data;
using System.Collections.Generic;
namespace Trees
    
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var lines = File.ReadLines("scores.txt");
            foreach (string sorting in lines.OrderBy(x => Convert.ToInt32(x.Split('|').Last().Replace("Number: ", "").Trim()) * -1))
            {
                WriteLine(sorting);
             

            }

            Treenode nody = new Treenode();
        }

    }
}
