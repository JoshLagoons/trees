﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trees
{
    class Treeview
    {
        internal static TreeNodeCollection nodes;
    }
}
